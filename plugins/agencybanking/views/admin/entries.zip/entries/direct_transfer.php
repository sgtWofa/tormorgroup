<?php if(user_can('add_agencybanking')):?>
	<style>
		form {
			margin-top: 40px !important;
		}
		.form-control, .form-select {
			border-top: none !important;
			border-left: 0.5px solid gray !important;
			border-right: none !important;
			border: 1px solid yellowgreen;
			border-radius: 5px !important;
		}
		.input-group-text{
			font-weight: bolder;
		}
		.form-label {
			color: gray;
			font-size: 12px;
		}
	</style>
	<form method="post" enctype="multipart/form-data">		
		<div class="row col-9 col-lg-6 mx-auto shadow p-4 rounded mb-5">
			
			<?=csrf()?>

			<h4 class="text-center">
				<span><img src="<?=APP_LOGO2 ?? ''?>" style="cursor:pointer;width:100%;max-width:60px;max-height: 60px;object-fit: cover;"></span>
				Direct Transfer
			</h4>
	 
			<div class="mb-1">
				<label for="transaction_type" class="form-label">Transaction type</label>
				<select class="form-select transaction_type" id="transaction_type" name="transaction_type" onchange="updateCategoryOptions()" onchange="updateSourceOptions()">
				  <option value="">---Select---</option>
				  <option <?=old_select('transaction_type','Direct transfer (CIT)')?> value="Direct transfer (CIT)" selected>Direct transfer (CIT)</option>
				</select>
				<?php if(!empty($errors['transaction_type'])):?>
				  <small class="text-danger"><?=$errors['transaction_type']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-1">
				<label for="network" class="form-label">Source bank</label>
				<select class="form-select" name="network" id="network">			  
				  <!-- Options will be populated dynamically based on transaction type -->
				</select>
				<?php if(!empty($errors['network'])):?>
				  <small class="text-danger"><?=$errors['network']?></small>
				<?php endif?>
			</div>
	 

			<div class="mb-1">
			  <label for="phone" class="form-label">Phone</label>
			  <input name="phone" value="<?=old_value('phone')?>" type="text" class="form-control" id="phone" placeholder="Enter phone number">
				
				<?php if(!empty($errors['phone'])):?>
				  <small class="text-danger"><?=$errors['phone']?></small>
				<?php endif?>
			</div>

			<div class="mb-1 account_number">
			  <label for="account_number" class="form-label">Customer name</label>
			  <input name="account_number" value="<?=old_value('account_number')?>" type="text" class="form-control" id="account_number" placeholder="Customer name">
				
				<?php if(!empty($errors['account_number'])):?>
				  <small class="text-danger"><?=$errors['account_number']?></small>
				<?php endif?>
			</div>

			<div class="mb-1 balance_before">
			  <label for="balance_before" class="form-label">Amount Transferred</label>
			  <input name="balance_before" value="<?=old_value('balance_before')?>" type="number" step="0.01" class="form-control" id="balance_before" placeholder="Enter amount transferred">
				
				<?php if(!empty($errors['balance_before'])):?>
				  <small class="text-danger"><?=$errors['balance_before']?></small>
				<?php endif?>
			</div>

			<div class="mb-1 charge">
			  <label for="charge" class="form-label">Charge <small>(to be negotiated)</small></label>
			  <input name="charge" value="<?=old_value('charge')?>" type="number" step="0.01" class="form-control" id="charge" placeholder="Enter charge">
				
				<?php if(!empty($errors['charge'])):?>
				  <small class="text-danger"><?=$errors['charge']?></small>
				<?php endif?>
			</div>

			<div class="mb-1 amount_to_pay">
			  <label for="amount_to_pay" class="form-label">Amount to Pay</label>
			  <input name="amount_to_pay" value="<?=old_value('amount_to_pay')?>" type="text" class="form-control" id="amount_to_pay" placeholder="GH&cent;" readonly>
				  <small class="text-danger" id="amount_to_pay-error"></small>
			</div>

		    <!-- Amount Input with Calculator Modal Trigger -->
		    <div class="col-md-12">
		      <label for="amount" class="form-label">Amount Paid Out</label>
			   <label class="input-group" data-bs-toggle="modal" data-bs-target="#staticBackdrop"> 
		        <i class="fa-solid fa-calculator input-group-text text-warning"></i>
		          <input name="amount" type="number" step="0.01" class="form-control" id="amount" placeholder="Enter amount" readonly>
			      <input type="hidden" id="denos" name="denos" />
		      </label>
		      <?php if(!empty($errors['amount'])):?>
		        <small class="text-danger"><?=$errors['amount']?></small>
		    <?php endif;?>
				 <small class="text-danger" id="amount_to_pay-error"></small>
		    </div>

			<div class="mb-1 wallet_in_id">
			  <label for="wallet_in_id" class="form-label">Receiving Wallet</label>
			  <select class="form-select id_type" name="wallet_in_id" id="wallet_in_id">
				  <option value="">---Select---</option>
				  <?php if(!empty($wallets)):?>
				  	<?php foreach ($wallets as $wallet): ?>		
				  	<?php if (strtolower($wallet->wallet_type) === 'cash'): ?>
				  		<option <?=old_select('wallet_in_id', $wallet->id)?> value="<?=$wallet->id?>"><?=$wallet->name . ' ' . $wallet->network ?? ''?> [<?=number_format($wallet->balance ?? 0, 2)?>]</option>
				  	<?php endif ?>	  	
				  	<?php endforeach ?>
				  <?php endif;?>
			  </select>			
				<?php if(!empty($errors['wallet_in_id'])):?>
				  <small class="text-danger"><?=$errors['wallet_in_id']?></small>
				<?php endif?>
			</div>

			<div class="mb-1 wallet_out_id">
			  <label for="wallet_out_id" class="form-label">Paying Wallet</label>
			  <select class="form-select id_type" name="wallet_out_id" id="wallet_out_id">
				  <option value="">---Select---</option>
				  <?php if(!empty($wallets)):?>
				  	<?php foreach ($wallets as $wallet): ?>			
					  	<?php if (strtolower($wallet->wallet_type) === 'bank'): ?>
					  		<option <?=old_select('wallet_in_id', $wallet->id)?> value="<?=$wallet->id?>"><?=$wallet->name . ' ' . $wallet->network ?? ''?> [<?=number_format($wallet->balance ?? 0, 2)?>]</option>
					  	<?php endif ?>
				  	<?php endforeach ?>
				  <?php endif;?>
			  </select>			
				<?php if(!empty($errors['wallet_out_id'])):?>
				  <small class="text-danger js-wallet-out-error"><?=$errors['wallet_out_id']?></small>
				<?php endif?>
			</div>

			<div class="mb-1 transaction_status">
			  <label for="transaction_status" class="form-label">Status</label>
			  <select class="form-select transaction_status" name="transaction_status">
				  <option value="">---Select---</option>
				  <option <?=old_select('transaction_status','Draft')?> value="Draft">Draft</option>
				  <option <?=old_select('transaction_status','Pending')?> value="Pending">Pending</option>
				 <?php if(user_can('approve_transactions')):?>
				  <option <?=old_select('transaction_status','Rejected')?> value="Rejected">Rejected</option>
				  <option <?=old_select('transaction_status','Paid')?> value="Paid">Paid</option>
				<?php endif;?>
			  </select>
			</div>
	 
			<div class="d-flex justify-content-between" style="margin-top:10px;">
				<a href="<?=ROOT?>/<?=$admin_route?>/<?=$plugin_route?>">
					<button type="button" class="btn btn-primary">
						<i class="fa-solid fa-chevron-left"></i> Back
					</button>
				</a>
				<button class="btn btn-danger" id="save">
					<i class="fa-solid fa-save"></i> Save
				</button>
			</div>
		</div>
	</form>

	<!-- Calculator modal -->
	<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <!-- Modal Header -->
	      <div class="modal-header">
	        <h5 class="modal-title" id="staticBackdropLabel">Currency Notes</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>

	      <!-- Modal Body -->
	      <div class="modal-body table-responsive">

	        <table class="table table-hover table-sm">
	          <thead>
	            <tr>
	              <th>NOTES</th>
	              <th>COUNT</th>
	              <th>VOLUME</th>
	            </tr>
	          </thead>
	          <tbody>
	            <tr data-denomination="200">
	              <td class="px-5">GH&cent;200</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Volume" readonly></td>
	            </tr>
	            <tr data-denomination="100">
	              <td class="px-5">GH&cent;100</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Volume" readonly></td>
	            </tr>
	             <tr data-denomination="50">
	              <td class="px-5">GH&cent;50</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="20">
	              <td class="px-5">GH&cent;20</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="10">
	              <td class="px-5">GH&cent;10</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="5">
	              <td class="px-5">GH&cent;5</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="2">
	              <td class="px-5">GH&cent;2</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="1">
	              <td class="px-5">GH&cent;1</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr>
	              <td colspan="3">COINS</td>
	            </tr>
	            <tr data-denomination="2">
	              <td class="px-5">GH&cent;2</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="1">
	              <td class="px-5">GH&cent;1</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.5">
	              <td class="px-5">50p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.2">
	              <td class="px-5">20p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.1">
	              <td class="px-5">10p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	          </tbody>
	          <tfoot>
	            <tr>
	              <th class="px-5 bg-secondary text-warning">TOTAL</th>
	              <th class="bg-secondary text-warning"><input type="text" class="form-control p-1" id="total-count" style="border:none; " placeholder="Total count" readonly></th>
	              <th class="bg-secondary text-warning"><input type="text" class="form-control p-1" id="total-volume" style="border:none; " placeholder="Total volume" readonly></th>
	            </tr>
	          </tfoot>
	        </table>
	      </div>

	      <!-- Modal Footer -->
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-danger reset" >Reset</button>
	        <button type="button" class="btn btn-warning restore" >Restore</button>
	        <button type="button" class="btn btn-primary submit">Confirm</button>
	      </div>
	    </div>
	  </div>
	</div>

<?php else:?>
	<div class="alert alert-danger text-center">
		Access denied. You dont have permission for this action
	</div>
<?php endif?>

<script>

	const sourceOptions = {
		
		"Direct transfer (CIT)": [
			{ value: "", text: "---Select---" },
			{ value: "ABSA", text: "ABSA" },
			{ value: "Access Bank", text: "Access Bank" },
			{ value: "ADB", text: "ADB" },
			{ value: "APEX BANK", text: "APEX BANK" },
			{ value: "Bank of Africa", text: "Bank of Africa" },
			{ value: "Cal bank", text: "Cal bank" },
			{ value: "CBG", text: "CBG" },
			{ value: "Ecobank", text: "Ecobank" },
			{ value: "Fidelity", text: "Fidelity" },
			{ value: "First Atlantic Bank", text: "First Atlantic Bank" },
			{ value: "First Bank Ghana", text: "First Bank Ghana" },
			{ value: "FNB", text: "FNB" },
			{ value: "GCB", text: "GCB" },
			{ value: "Ghana Pay", text: "Ghana Pay" },
			{ value: "Gtbank", text: "Gtbank" },
			{ value: "NIB", text: "NIB" },
			{ value: "Prudential Bank", text: "Prudential Bank" },
			{ value: "Republic Bank", text: "Republic Bank" },
			{ value: "OmniBSIC Bank", text: "OmniBSIC Bank" },
			{ value: "Society General", text: "Society General" },
			{ value: "Stanbic Bank", text: "Stanbic Bank" },
			{ value: "Standard Charted", text: "Standard Charted" },
			{ value: "UBA", text: "UBA" },
			{ value: "umb", text: "umb" },
			{ value: "Zenit Bank", text: "Zenit Bank" },
		],
	};

	const transactionType = document.getElementById('transaction_type'); // Corrected ID selection
	const sourceSelect = document.getElementById('network');
	const amountInput = document.getElementById('amount');
	const amount_to_payInput = document.getElementById('amount_to_pay');
	const chargeInput = document.getElementById('charge');
	const saveBtn = document.getElementById('save');
	const amount_to_payError = document.querySelector('#amount_to_pay-error');
	saveBtn.disabled= true;

	function updateSourceOptions() {
		const transactionTypeValue = transactionType.value;
		sourceSelect.innerHTML = ""; // Clear current options

		// Populate options based on selected transaction type
		if (sourceOptions[transactionTypeValue]) {
			sourceOptions[transactionTypeValue].forEach(option => {
				const opt = document.createElement('option');
				opt.value = option.value;
				opt.textContent = option.text;
				sourceSelect.appendChild(opt);
			});
		} 
	}


	function calculateAmountPayable() {
		const transactionType = document.getElementById('transaction_type').value;
		const balanceBefore = parseFloat(document.getElementById('balance_before').value) || 0;
		const amount = parseFloat(document.getElementById('amount').value) || 0;
		const charge = parseFloat(document.getElementById('charge').value) || 0;
		const amount_to_payField = document.getElementById('amount_to_pay');

		let newBalance = balanceBefore;

		// Adjust balance based on transaction type
		switch (transactionType) {
			case 'Direct transfer (CIT)':
				newBalance = balanceBefore - charge;
				break;
			default:
				// For other transaction types, keep balance unchanged or handle as needed
				newBalance = balanceBefore;
				break;
		}

		amount_to_payField.value = newBalance.toFixed(2);
		if (amount > newBalance || amount < newBalance) {
			amount_to_payError.innerText = "Amount paid out must be equal to amount to pay";
			saveBtn.disabled = true;
			return;
		}else{
			amount_to_payError.innerText = "";
			saveBtn.disabled = false;
		}
	}

	// Initialize on page load
	document.addEventListener("DOMContentLoaded", function() {

      const countInputs = document.querySelectorAll(".count-input");
	  const totalCountField = document.getElementById("total-count");
	  const totalVolumeField = document.getElementById("total-volume");
	  const denosField = document.querySelector("#denos");
	  const submitBtn = document.querySelector('.submit');
	  const restoreBtn = document.querySelector('.restore');
	  const resetBtn = document.querySelector('.reset');
	  const staticBackdropModal = new bootstrap.Modal(document.getElementById('staticBackdrop'));
	  const amountInput = document.getElementById("amount");
	  // Load denomination data from localStorage
	  const savedDenos = localStorage.getItem("denosData");

	  function restoreDenominations() {
	    if (savedDenos) {
	      const currency = JSON.parse(savedDenos);

	      currency.forEach((item, index) => {
	        const input = countInputs[index];
	        if (input) {
	          const row = input.closest("tr");
	          const volumeField = row.querySelector(".volume-input");

	          // Restore count and volume values
	          input.value = item.count;
	          volumeField.value = (item.denomination * item.count).toFixed(2);
	        }
	      });

	      // Update totals
	      updateVolumesAndTotals();
	    }
	  }

	  function resetDenominations() {
	    if (savedDenos) {
	      const currency = JSON.parse(savedDenos);

	      currency.forEach((item, index) => {
	        const input = countInputs[index];
	        if (input) {
	          const row = input.closest("tr");
	          const volumeField = row.querySelector(".volume-input");

	          // Restore count and volume values
	          input.value = '';
	          volumeField.value = '';
	        }
	      });

	      // Update totals
	      updateVolumesAndTotals();
	    }
	  }

	  function restoreDenominations() {
	    const currentCurrency = currencySelect.value;
	    const currencyData = savedDenos[currentCurrency] || [];

	    const countInputs = document.querySelectorAll(".count-input");
	    countInputs.forEach(input => {
	      const row = input.closest("tr");
	      const denomination = parseFloat(row.getAttribute("data-denomination"));

	      const data = currencyData.find(item => item.denomination === denomination);
	      if (data) {
	        const volumeField = row.querySelector(".volume-input");
	        input.value = data.count;
	        volumeField.value = data.volume.toFixed(2);
	      }
	    });

	    updateVolumesAndTotals();
	  }
	countInputs.forEach(input => {
      input.addEventListener("input", updateVolumesAndTotals);
    });

    function updateVolumesAndTotals() {
	  let totalCount = 0;
	  let totalVolume = 0;
	  const currency = [];

	  countInputs.forEach(input => {
	    const row = input.closest("tr");
	    const denomination = parseFloat(row.getAttribute("data-denomination"));
	    const count = parseFloat(input.value) || 0;
	    const volumeField = row.querySelector(".volume-input");
	    const volume = denomination * count;

	    volumeField.value = volume.toFixed(2);
	    totalCount += count;
	    totalVolume += volume;

	    // Only add to currency array if count is greater than zero
	    if (count > 0) {
	      const denos = {
	        currency: `GHS`,
	        denomination: denomination,
	        count: count,
	        volume: volume,
	      };
	      currency.push(denos);
	    }
	  });

	  totalCountField.value = totalCount;
	  totalVolumeField.value = totalVolume.toFixed(2);

	  // Store serialized currency details in both localStorage and the hidden field
	  const serializedCurrency = JSON.stringify(currency);
	  localStorage.setItem("denosData", serializedCurrency);
	  denosField.value = serializedCurrency;
	}

	submitBtn.addEventListener('click', function() {
      amountInput.value = totalVolumeField.value;
   		updateVolumesAndTotals();
   		calculateAmountPayable();
      staticBackdropModal.hide();
    });
	    

    restoreBtn.addEventListener('click', function() {
    	// Restore denominations
  		restoreDenominations();
    });

    resetBtn.addEventListener('click', function() {
    	// Reset denominations
  		resetDenominations();
    });

		updateSourceOptions();
	});

	// Event listeners for real-time updates
	transactionType.addEventListener("change", updateSourceOptions);
	transactionType.addEventListener("change", calculateAmountPayable);
	document.getElementById('amount').addEventListener('input', function() {
		calculateAmountPayable();
		saveBtn.disabled = false;
	});
	document.getElementById('balance_before').addEventListener('input', calculateAmountPayable);
	document.getElementById('charge').addEventListener('input', calculateAmountPayable);
</script>


<?php if(user_can('add_agencybanking')):?>
	<style>
		form {
			margin-top: 40px !important;
		}
		.form-control, .form-select {
			border-top: none !important;
			border-left: 0.5px solid gray !important;
			border-right: none !important;
			border: 1px solid yellowgreen;
			border-radius: 5px !important;
		}
		.input-group-text{
			font-weight: bolder;
		}
		.form-label {
			color: gray;
			font-size: 12px;
		}
	</style>
	<form method="post" enctype="multipart/form-data">		
		<div class="row col-9 col-lg-5 mx-auto shadow p-4 mb-5 rounded">
			
			<?=csrf()?>

			<h4 class="text-center">
				<span><img src="<?=APP_LOGO2 ?? ''?>" style="cursor:pointer;width:100%;max-width:60px;max-height: 60px;object-fit: cover;"></span>
				Deposit
			</h4>
	 
			<div class="mb-2">
				<label for="transaction_type" class="form-label">Transaction type</label>
				<select class="form-select transaction_type" id="transaction_type" name="transaction_type" onchange="updateCategoryOptions()" onchange="updateSourceOptions()">
				  <option value="">---Select---</option>
				  <option <?=old_select('transaction_type','Deposit')?> value="Deposit" selected>Deposit</option>
				</select>

				<?php if(!empty($errors['transaction_type'])):?>
				  <small class="text-danger"><?=$errors['transaction_type']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2">
				<label for="network" class="form-label">Service provider</label>
				<select class="form-select" name="network" id="network" onchange="showFields()">			  
				  </select>
           <div id="networkError" class="text-error text-danger d-none">Service provider is required</div>

				<?php if(!empty($errors['network'])):?>
				  <small class="text-danger"><?=$errors['network']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2 category d-none">
				<label for="category" class="form-label">Category</label>
				<select class="form-select" name="category" id="category" onchange="showFields()">
				  </select>

				<?php if(!empty($errors['category'])):?>
				  <small class="text-danger"><?=$errors['category']?></small>
				<?php endif?>
			</div>

			<div class="mb-2">
			  <label for="phone" class="form-label">Phone</label>
			  <input name="phone" value="<?=old_value('phone')?>" type="text" class="form-control" id="phone" placeholder="Enter phone number">
          <div id="phoneError" class="text-error text-danger d-none">Phone number is required</div>
				
				<?php if(!empty($errors['phone'])):?>
				  <small class="text-danger"><?=$errors['phone']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 account_number d-none">
			  <label for="account_number" class="form-label">Account number</label>
			  <input name="account_number" value="<?=old_value('account_number')?>" type="text" class="form-control" id="account_number" placeholder="Enter account number">
                <div id="account_numberError" class="text-error text-danger d-none">Account number is required</div>
				
				<?php if(!empty($errors['account_number'])):?>
				  <small class="text-danger"><?=$errors['account_number']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 destination_bank d-none">
			  <label for="destination_bank" class="form-label">Destination bank</label>
			  <input name="destination_bank" value="<?=old_value('destination_bank')?>" type="text" class="form-control" id="destination_bank" placeholder="Enter destination bank ">			
				<?php if(!empty($errors['destination_bank'])):?>
				  <small class="text-danger"><?=$errors['destination_bank']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 cash_source d-none">
			  <label for="cash_source" class="form-label">Source of funds</label>
			  <input name="cash_source" value="<?=old_value('cash_source')?>" type="text" class="form-control" id="cash_source" placeholder="Enter source of funds">
				
				<?php if(!empty($errors['cash_source'])):?>
				  <small class="text-danger"><?=$errors['cash_source']?></small>
				<?php endif?>
			</div>

            <div class="mb-2">
                <label for="load" class="form-label">Load</label>
                <input
                  name="amount"
                  id="load"
                  type="number"
                  step="0.01"
                  class="form-control"
                  placeholder="Enter load"
                  value="<?=old_value('amount')?>"
                >
                <div id="loadError" class="text-error text-danger d-none">Load is required</div>
                <?php if(!empty($errors['amount'])):?>
                  <small class="text-danger"><?=$errors['amount']?></small>
                <?php endif?>
            </div>

            <div class="mb-2">
                <label for="amount_paid" class="form-label">Amount paid</label>
                <label class="input-group" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                    <i class="fa-solid fa-calculator input-group-text text-warning"></i>
                    <input
                      name="amount_paid"
                      id="amount_paid"
                      type="number"
                      step="0.01"
                      class="form-control"
                      placeholder="Amount paid"
                      readonly
                      value="<?=old_value('amount_paid')?>"
                    >
                    <input type="hidden" id="denos" name="denos" />
                </label>
                <div id="paidError"       class="text-error text-danger d-none">Amount paid is required</div>
                <div id="paidMismatchError" class="text-error text-danger">Amount paid must equal load</div>
                <?php if(!empty($errors['amount_paid'])):?>
                  <small class="text-danger"><?=$errors['amount_paid']?></small>
                <?php endif?>
            </div>

			<div class="mb-2 d-none">
			  <label for="charge" class="form-label">Charge </label>
			  <div class="input-group">
			  	<div id="currencySymbol" class="input-group-text">GH₵</div>
			  	<input name="charge" value="<?=old_value('charge')?>" type="text" class="form-control" id="charge" placeholder="GH&cent;0.00">
			  </div>
				
				<?php if(!empty($errors['charge'])):?>
				  <small class="text-danger"><?=$errors['charge']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 balance d-none">
			  <label for="balance" class="form-label">New Balance</label>
			  <input name="balance" value="<?=old_value('balance')?>" type="text" class="form-control" id="balance" placeholder="GH&cent;">
          <div id="balanceError" class="text-error text-danger d-none">Balance is required</div>
				
				<?php if(!empty($errors['balance'])):?>
				  <small class="text-danger"><?=$errors['balance']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 transaction_status d-none">
			  <label for="transaction_status" class="form-label">Status</label>
			  <select class="form-select transaction_status" name="transaction_status">
				  <option value="">---Select---</option>
				  <option <?=old_select('transaction_status','Draft')?> value="Draft">Draft</option>
				  <option <?=old_select('transaction_status','Pending')?> value="Pending">Pending</option>
				 <?php if(user_can('approve_transactions')):?>
				  <option <?=old_select('transaction_status','Rejected')?> value="Rejected">Rejected</option>
				  <option <?=old_select('transaction_status','Approved')?> value="Approved">Approved</option>
				<?php endif;?>
			  </select>				
				<?php if(!empty($errors['transaction_status'])):?>
				  <small class="text-danger"><?=$errors['transaction_status']?></small>
				<?php endif?>
			</div>
	 
			<div class="d-flex justify-content-between" style="margin-top:10px;">
				<a href="<?=ROOT?>/<?=$admin_route?>/<?=$plugin_route?>">
					<button type="button" class="btn btn-primary">
						<i class="fa-solid fa-chevron-left"></i> Back
					</button>
				</a>
                <button
                  type="submit"
                  class="btn btn-danger"
                  id="saveBtn"
                  disabled
                >
                  <i class="fa-solid fa-save"></i> Save
                </button>
			</div>
		</div>
	</form>

	<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="staticBackdropLabel">Currency Notes</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>

	      <div class="modal-body table-responsive">

	        <table class="table table-hover table-sm">
	          <thead>
	            <tr>
	              <th>NOTES</th>
	              <th>COUNT</th>
	              <th>VOLUME</th>
	            </tr>
	          </thead>
	          <tbody>
	            <tr data-denomination="200">
	              <td class="px-5">GH&cent;200</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Volume" readonly></td>
	            </tr>
	            <tr data-denomination="100">
	              <td class="px-5">GH&cent;100</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Volume" readonly></td>
	            </tr>
	             <tr data-denomination="50">
	              <td class="px-5">GH&cent;50</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="20">
	              <td class="px-5">GH&cent;20</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="10">
	              <td class="px-5">GH&cent;10</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="5">
	              <td class="px-5">GH&cent;5</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="2">
	              <td class="px-5">GH&cent;2</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="1">
	              <td class="px-5">GH&cent;1</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr>
	              <td colspan="3">COINS</td>
	            </tr>
	            <tr data-denomination="2">
	              <td class="px-5">GH&cent;2</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="1">
	              <td class="px-5">GH&cent;1</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.5">
	              <td class="px-5">50p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.2">
	              <td class="px-5">20p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.1">
	              <td class="px-5">10p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	          </tbody>
	          <tfoot>
	            <tr>
	              <th class="px-5 bg-secondary text-warning">TOTAL</th>
	              <th class="bg-secondary text-warning"><input type="text" class="form-control p-1" id="total-count" style="border:none; " placeholder="Total count" readonly></th>
	              <th class="bg-secondary text-warning"><input type="text" class="form-control p-1" id="total-volume" style="border:none; " placeholder="Total volume" readonly></th>
	            </tr>
	          </tfoot>
	        </table>
	      </div>

	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-danger reset" >Reset</button>
	        <button type="button" class="btn btn-warning restore" >Restore</button>
	        <button type="button" class="btn btn-primary submit">Confirm</button>
	      </div>

            <div id="modalMismatch" class="text-error text-danger mb-2"></div>
	    </div>
	  </div>
	</div>

<?php else:?>
	<div class="alert alert-danger text-center">
		Access denied. You dont have permission for this action
	</div>
<?php endif?>

<script>
	const categoryOptions = {
		"Deposit": [
			{ value: "", text: "---Select---" },
			{ value: "self", text: "self" },
			{ value: "3rd party", text: "3rd party" }
		]
	};

	const sourceOptions = {
		
		"Deposit": [
			{ value: "", text: "---Select---" },
			{ value: "Access Bank", text: "Access Bank" },
			{ value: "Fidelity", text: "Fidelity" },
			{ value: "Cal bank", text: "Cal bank" },
			{ value: "Ecobank", text: "Ecobank" },
			{ value: "FBN", text: "FBN" },
			{ value: "Gtbank", text: "Gtbank" },
		]
	};

	const transactionType = document.getElementById('transaction_type'); // Corrected ID selection
	const categorySelect = document.getElementById('category');
	const amountPaidInput = document.getElementById('amount_paid');
	const networkSelect = document.getElementById('network');
	const categoryDiv = document.querySelector('.category');

    const loadInput       = document.getElementById('load');
    const paidInput       = document.getElementById('amount_paid');
    const phoneInput    = document.getElementById('phone');
    const account_numberInput    = document.getElementById('account_number');
    const balanceInput    = document.getElementById('balance');
    const saveBtn         = document.getElementById('saveBtn');
    const modalMismatch    = document.getElementById('modalMismatch');

    // error placeholders
    const mismatchError    = document.getElementById('paidMismatchError');
    const loadError       = document.getElementById('loadError');
    const paidError       = document.getElementById('paidError');
    const balanceError    = document.getElementById('balanceError');
    const networkError    = document.getElementById('networkError');
    const phoneError    = document.getElementById('phoneError');
    const account_numberError    = document.getElementById('account_numberError');

	function updateCategoryOptions() {
		const transactionTypeValue = transactionType.value;
		categorySelect.innerHTML = ""; // Clear current options

		// Populate options based on selected transaction type
		if (categoryOptions[transactionTypeValue]) {
			categorySelect.classList.remove('d-none');
			categoryDiv.classList.remove('d-none');
			categoryOptions[transactionTypeValue].forEach(option => {
				const opt = document.createElement('option');
				opt.value = option.value;
				opt.textContent = option.text;
				categorySelect.appendChild(opt);
			});
		} else {
			categorySelect.classList.add('d-none'); // Hide if no options are available
			categoryDiv.classList.add('d-none'); // Hide if no options are available
		}
		showFields();
	}

	function updateSourceOptions() {
		const transactionTypeValue = transactionType.value;
		networkSelect.innerHTML = ""; // Clear current options

		// Populate options based on selected transaction type
		if (sourceOptions[transactionTypeValue]) {
			sourceOptions[transactionTypeValue].forEach(option => {
				const opt = document.createElement('option');
				opt.value = option.value;
				opt.textContent = option.text;
				networkSelect.appendChild(opt);
			});
		} 
		showFields();
	}

	function showFields() {
		const networkValue = networkSelect.value;
		const transactionTypeValue = transactionType.value;
		const categoryValue = categorySelect.value;
		const account_number = document.querySelector('.account_number');
		const destination_bank = document.querySelector('.destination_bank');
		const balance = document.querySelector('.balance');
		const transaction_status = document.querySelector('.transaction_status');

		account_number.classList.add('d-none');
		destination_bank.classList.add('d-none');
		balance.classList.add('d-none');
		transaction_status.classList.add('d-none');

		// Show fields based on selected category for Deposit
		if (transactionTypeValue === 'Deposit') {
			account_number.classList.remove('d-none');
			balance.classList.remove('d-none');
			transaction_status.classList.remove('d-none');
		}
	}

	// Initialize on page load
	document.addEventListener("DOMContentLoaded", function() {

      const countInputs = document.querySelectorAll(".count-input");
	  const totalCountField = document.getElementById("total-count");
	  const totalVolumeField = document.getElementById("total-volume");
	  const denosField = document.querySelector("#denos");
	  const confirmBtn = document.querySelector('.submit');
	  const restoreBtn = document.querySelector('.restore');
	  const resetBtn = document.querySelector('.reset');
	  const staticBackdropModal = new bootstrap.Modal(document.getElementById('staticBackdrop'));
	  
	  // Load denomination data from localStorage
	  const savedDenos = localStorage.getItem("denosData");

	  let attempted = false;

	  function restoreDenominations() {
	    if (savedDenos) {
	      const currency = JSON.parse(savedDenos);

	      currency.forEach((item, index) => {
	        const input = countInputs[index];
	        if (input) {
	          const row = input.closest("tr");
	          const volumeField = row.querySelector(".volume-input");

	          // Restore count and volume values
	          input.value = item.count;
	          volumeField.value = (item.denomination * item.count).toFixed(2);
	        }
	      });

	      // Update totals
	      updateVolumesAndTotals();
	    }
	  }

	  function resetDenominations() {
	    if (savedDenos) {
	      const currency = JSON.parse(savedDenos);

	      currency.forEach((item, index) => {
	        const input = countInputs[index];
	        if (input) {
	          const row = input.closest("tr");
	          const volumeField = row.querySelector(".volume-input");

	          // Restore count and volume values
	          input.value = '';
	          volumeField.value = '';
	        }
	      });

	      // Update totals
	      updateVolumesAndTotals();
	    }
	  }

    function updateVolumesAndTotals() {
	  let totalCount = 0;
	  let totalVolume = 0;
	  const currency = [];

	  countInputs.forEach(input => {
	    const row = input.closest("tr");
	    const denomination = parseFloat(row.getAttribute("data-denomination"));
	    const count = parseFloat(input.value) || 0;
	    const volumeField = row.querySelector(".volume-input");
	    const volume = denomination * count;

	    volumeField.value = volume.toFixed(2);
	    totalCount += count;
	    totalVolume += volume;

	    // Only add to currency array if count is greater than zero
	    if (count > 0) {
	      const denos = {
	        currency: `GHS`,
	        denomination: denomination,
	        count: count,
	        volume: volume,
	      };
	      currency.push(denos);
	    }
	  });

	  totalCountField.value = totalCount;
	  totalVolumeField.value = totalVolume.toFixed(2);

	  // Store serialized currency details in both localStorage and the hidden field
	  const serializedCurrency = JSON.stringify(currency);
	  localStorage.setItem("denosData", serializedCurrency);
	  denosField.value = serializedCurrency;
	}

    // override validateForm:
		function validateForm() {
		    const lv = parseFloat(loadInput.value)||0;
		    const pv = parseFloat(paidInput.value)||0;
		    const bv = balanceInput.value.trim();
		    const nv = networkSelect.value.trim();

		    if (!attempted) {
		        // never show errors until user tries
		        saveBtn.disabled = true;
		        mismatchError.classList.add('d-none');
		        return;
		    }

		    // toggle required-field errors
		    loadError      .classList.toggle('d-none', !!loadInput.value);
		    paidError      .classList.toggle('d-none', !!paidInput.value);
		    balanceError   .classList.toggle('d-none', !!balanceInput.value);
		    networkError   .classList.toggle('d-none', !!networkSelect.value);
		    phoneError   .classList.toggle('d-none', !!phoneInput.value);
		    account_numberError   .classList.toggle('d-none', !!account_numberInput.value);

		    // mismatch
		    const mismatch = (pv !== lv) && paidInput.value;
		    mismatchError .classList.toggle('d-none', !mismatch);

		    // enable Save only if all filled & no mismatch
		    const allFilled = loadInput.value && paidInput.value && balanceInput.value && networkSelect.value && phoneInput.value && account_numberInput.value;
		    const ok = allFilled && !mismatch;
		    saveBtn.disabled = !ok;
		}

    confirmBtn.addEventListener('click', function(){
    	attempted = true;                // now show errors
        updateVolumesAndTotals();
        const loadVal = parseFloat(loadInput.value)||0;
        const paidVal = parseFloat(totalVolumeField.value)||0;
        const diff = (paidVal - loadVal).toFixed(2);

        if (diff != 0) {
            modalMismatch.textContent = `Mismatch: ${diff>0?'+':'‒'}GH₵${Math.abs(diff)}`;
            modalMismatch.style.display = 'block';
        } else {
            paidInput.value    = paidVal.toFixed(2);
            //balanceInput.value = (paidVal - loadVal).toFixed(2);
            modalMismatch.style.display = 'none';
            staticBackdropModal.hide();
            validateForm();
        }
    });
	    


	countInputs.forEach(input => {
      input.addEventListener("input", updateVolumesAndTotals);
    });

    restoreBtn.addEventListener('click', function() {
    	// Restore denominations
  		restoreDenominations();
    });

    resetBtn.addEventListener('click', function() {
    	// Reset denominations
  		resetDenominations();
    });

    // Watch for changes on load, paid (set by modal “Confirm”) and balance
    loadInput.addEventListener('input', validateForm);
    paidInput.addEventListener('change', validateForm);  // after modal confirm
    phoneInput.addEventListener('input', validateForm);  // after modal confirm
    account_numberInput.addEventListener('input', validateForm);  // after modal confirm
    balanceInput.addEventListener('input', validateForm);
    networkSelect.addEventListener('change', validateForm);

    // Hook into your existing modal submit handler:
    const submitDenoBtn = document.querySelector('.submit');
    submitDenoBtn.addEventListener('click', function() {
        // existing code that sets amount_paid = totalVolumeField.value
        // then hide modal...
        // finally:
        validateForm();
    });

	// on Save click:
	saveBtn.addEventListener('click', function(e){
	    attempted = true;
	    validateForm();
	    if (saveBtn.disabled) {
	        e.preventDefault(); // stop actual submit if invalid
	    }
	});

		// Event listeners for real-time updates
		transactionType.addEventListener("change", updateCategoryOptions);
		transactionType.addEventListener("change", updateSourceOptions);
		categorySelect.addEventListener("change", showFields);

    validateForm();
		updateCategoryOptions();
		updateSourceOptions();
	});
</script>
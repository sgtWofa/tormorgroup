<?php if(user_can('add_agencybanking')):?>
	<style>
		form {
			margin-top: 40px !important;
		}
		.form-control, .form-select {
			border-top: none !important;
			border-left: 0.5px solid gray !important;
			border-right: none !important;
			border: 1px solid yellowgreen;
			border-radius: 5px !important;
		}
		.input-group-text{
			font-weight: bolder;
		}
		.form-label {
			color: gray;
			font-size: 12px;
		}
	</style>
	<form method="post" enctype="multipart/form-data">		
		<div class="row col-9 col-lg-5 mx-auto shadow mb-5 p-4 rounded">
			
			<?=csrf()?>

			<h4 class="text-center">
				<span><img src="<?=APP_LOGO2 ?? ''?>" style="cursor:pointer;width:100%;max-width:60px;max-height: 60px;object-fit: cover;"></span>
				New Withdrawal
			</h4>
	 
			<div class="mb-2">
				<label for="transaction_type" class="form-label">Transaction type</label>
				<select class="form-select transaction_type" id="transaction_type" name="transaction_type"  onchange="updateSourceOptions()">
				  <option value="">---Select---</option>
				  <option <?=old_select('transaction_type','Withdrawal (AIT)')?> value="Withdrawal (AIT)">Withdrawal (AIT)</option>
				  <option <?=old_select('transaction_type','Withdrawal (CIT)')?> value="Withdrawal (CIT)">Withdrawal (CIT)</option>
				</select>

				<?php if(!empty($errors['transaction_type'])):?>
				  <small class="text-danger"><?=$errors['transaction_type']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2">
				<label for="network" class="form-label">Service provider</label>
				<select class="form-select" name="network" id="network">			  
				  </select>

				<?php if(!empty($errors['network'])):?>
				  <small class="text-danger"><?=$errors['network']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2 d-none category">
				<label for="category" class="form-label">CIT Type</label>
				<select class="form-select" name="category" id="category">		
				  <option value="">---Select---</option>
				  <option <?=old_select('category','Self')?> value="Self">Self</option>
				  <option <?=old_select('category','3rd Party')?> value="3rd Party">3rd Party</option>	  
				</select>
				<?php if(!empty($errors['category'])):?>
				  <small class="text-danger"><?=$errors['category']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2 d-none payment_medium">
				<label for="payment_medium" class="form-label">Medium Used</label>
				<select class="form-select" name="payment_medium" id="payment_medium">		
				  <option value="">---Select---</option>
				  <option <?=old_select('payment_medium','Fidelity App')?> value="Fidelity App">Fidelity App</option>
				  <option <?=old_select('payment_medium','Fidelity-GhQr ussd')?> value="Fidelity-GhQr ussd">Fidelity-GhQr ussd</option>	  
				  <option <?=old_select('payment_medium','Fidelity ussd')?> value="Fidelity ussd">Fidelity ussd</option>	  
				  <option <?=old_select('payment_medium','Other ussd')?> value="Other ussd">Other ussd</option>	  
				</select>
				<?php if(!empty($errors['payment_medium'])):?>
				  <small class="text-danger"><?=$errors['payment_medium']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 phone">
			  <label for="phone" class="form-label phoneLabel">Phone</label>
			  <input name="phone" value="<?=old_value('phone')?>" type="text" class="form-control" id="phone" placeholder="Enter phone number">				
				<?php if(!empty($errors['phone'])):?>
				  <small class="text-danger"><?=$errors['phone']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 otherPartyNumber d-none">
			  <label for="other_phone" class="form-label">3rd Party's number</label>
			  <input name="other_phone" value="<?=old_value('other_phone')?>" type="text" class="form-control" id="other_phone" placeholder="Enter other_phone number">				
				<?php if(!empty($errors['other_phone'])):?>
				  <small class="text-danger"><?=$errors['other_phone']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 account_number">
			  <label for="account_number" class="form-label">Account number</label>
			  <input name="account_number" value="<?=old_value('account_number')?>" type="text" class="form-control" id="account_number" placeholder="Enter account number">
				
				<?php if(!empty($errors['account_number'])):?>
				  <small class="text-danger"><?=$errors['account_number']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 balance_before d-none">
			  <label for="balance_before" class="form-label">Balance before</label>
			  <input name="balance_before" value="<?=old_value('balance_before')?>" type="number" step="0.01" class="form-control" id="balance_before" placeholder="Enter balance_before">
				
				<?php if(!empty($errors['balance_before'])):?>
				  <small class="text-danger"><?=$errors['balance_before']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 amount_withdrawn d-none">
			  <label for="amount_withdrawn" class="form-label">Amount withdrawn</label>
			  <input name="amount_withdrawn" value="<?=old_value('amount_withdrawn')?>" type="number" step="0.01" class="form-control" id="amount_withdrawn" placeholder="Enter amount withdrawn">
				
				<?php if(!empty($errors['amount_withdrawn'])):?>
				  <small class="text-danger"><?=$errors['amount_withdrawn']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2 sof_option d-none">
				<label for="sof_option" class="form-label">Source Option</label>
				<select class="form-select" name="sof_option" id="sof_option">		
				  <option value="">---Select---</option>
				  <option <?=old_select('sof_option','Telco')?> value="Telco">Telco</option>
				  <option <?=old_select('sof_option','Bank')?> value="Bank">Bank</option>	  
				</select>
				<?php if(!empty($errors['sof_option'])):?>
				  <small class="text-danger"><?=$errors['sof_option']?></small>
				<?php endif?>
			</div>
	 
			<div class="mb-2 sof d-none">
				<label for="sof" class="form-label">Source of Funds</label>
				<select class="form-select" name="cash_source" id="sof">		
				  <option value="">---Select---</option>
				  </select>
				<?php if(!empty($errors['cash_source'])):?>
				  <small class="text-danger"><?=$errors['cash_source']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 amount_payable d-none">
			  <label for="amount_payable" class="form-label">Amount after Charge (amount payable)</label>
			  <input name="amount_payable" value="<?=old_value('amount_payable')?>" type="number" step="0.01" class="form-control disabled" id="amount_payable" placeholder="Amount payable" readonly>
				
				<?php if(!empty($errors['amount_payable'])):?>
				  <small class="text-danger"><?=$errors['amount_payable']?></small>
				<?php endif?>
			</div>

		    <div class="col-md-12">
		      <label for="amount" class="form-label">Amount Paid out</label>
			   <label class="input-group" data-bs-toggle="modal" data-bs-target="#staticBackdrop"> 
		        <i class="fa-solid fa-calculator input-group-text text-warning"></i>
		          <input name="amount" type="number" step="0.01" class="form-control" id="amount" placeholder="Enter amount" readonly>
			      <input type="hidden" id="denos" name="denos" />
		      </label>
		      <?php if(!empty($errors['amount'])):?>
		        <small class="text-danger"><?=$errors['amount']?></small>
		      <?php endif?>
				<?php if(!empty($errors['wallet_out_id'])):?>
				  <small class="text-danger"><?=$errors['wallet_out_id']?></small>
				<?php endif?>
				<small class="text-danger" id="amount-match-error" style="display: none;">Amount withdrawn must match amount paid out</small>
		    </div>

			<div class="mb-1 balance">
			  <label for="balance" class="form-label">New Balance</label>
			  <input name="balance" value="<?=old_value('balance')?>" type="text" class="form-control" id="balance" placeholder="GH&cent;" readonly>
				
				<?php if(!empty($errors['balance'])):?>
				  <small class="text-danger"><?=$errors['balance']?></small>
				<?php endif?>
				  <small class="text-danger" id="balance-error"></small>
			</div>

			<div class="mb-2 wallet_in_id">
			  <label for="wallet_in_id" class="form-label">Receiving Wallet</label>
			  <select class="form-select id_type" name="wallet_in_id" id="wallet_in_id" required>
				  <option value="">---Select---</option>
				  <?php if(!empty($wallets)):?>
				  	<?php foreach ($wallets as $wallet): ?>	
				  		<?php if ($wallet->wallet_type !== 'Cash'): ?>				  		
				  			<option <?=old_select('wallet_in_id', $wallet->id)?> value="<?=$wallet->id?>"><?=$wallet->name . ' ' . $wallet->network ?? ''?> [<?=number_format($wallet->balance ?? 0, 2)?>]</option>
				 		 <?php endif;?>
				  	<?php endforeach ?>
				  <?php endif;?>
			  </select>			
				<?php if(!empty($errors['wallet_in_id'])):?>
				  <small class="text-danger"><?=$errors['wallet_in_id']?></small>
				<?php endif?>
			</div>
			<div class="mb-2 wallet_out_id">
			  <label for="wallet_out_id" class="form-label">Paying Wallet</label>
			  <select class="form-select id_type" name="wallet_out_id" id="wallet_out_id" required>
				  <option value="">---Select---</option>
				  <?php if(!empty($mywallets)):?>
				  	<?php foreach ($mywallets as $wallet): ?>
				  		<?php if ($wallet->wallet_type === 'Cash'): ?>				  					  			
				  			<option <?=old_select('wallet_out_id', $wallet->id)?> value="<?=$wallet->id?>"><?=$wallet->name . ' ' . $wallet->network ?? ''?> [<?=number_format($wallet->balance ?? 0, 2)?>]</option>
				  		<?php endif ?>			  		
				  	<?php endforeach ?>
				  <?php endif;?>
			  </select>			
				<?php if(!empty($errors['wallet_out_id'])):?>
				  <small class="text-danger js-wallet-out-error"><?=$errors['wallet_out_id']?></small>
				<?php endif?>
			</div>

			<div class="mb-2 transaction_status">
			  <label for="transaction_status" class="form-label">Status</label>
			  <select class="form-select transaction_status" name="transaction_status">
				  <option value="">---Select---</option>
				  <option <?=old_select('transaction_status','Draft')?> value="Draft">Draft</option>
				  <option <?=old_select('transaction_status','Pending')?> value="Pending">Pending</option>
				 <?php if(user_can('approve_transactions')):?>
				  <option <?=old_select('transaction_status','Rejected')?> value="Rejected">Rejected</option>
				  <option <?=old_select('transaction_status','Approved')?> value="Approved">Approved</option>
				<?php endif;?>
			  </select>
				
				<?php if(!empty($errors['transaction_status'])):?>
				  <small class="text-danger"><?=$errors['transaction_status']?></small>
				<?php endif?>
			</div>
	 
			<div class="d-flex justify-content-between" style="margin-top:10px;">
				<a href="<?=ROOT?>/<?=$admin_route?>/<?=$plugin_route?>">
					<button type="button" class="btn btn-primary">
						<i class="fa-solid fa-chevron-left"></i> Back
					</button>
				</a>
				<button class="btn btn-danger save disabled">
					<i class="fa-solid fa-save"></i> Save
				</button>
			</div>
		</div>
	</form>

	<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="staticBackdropLabel">Currency Notes</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>

	      <div class="modal-body table-responsive">

	        <table class="table table-hover table-sm">
	          <thead>
	            <tr>
	              <th>NOTES</th>
	              <th>COUNT</th>
	              <th>VOLUME</th>
	            </tr>
	          </thead>
	          <tbody>
	            <tr data-denomination="200">
	              <td class="px-5">GH&cent;200</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Volume" readonly></td>
	            </tr>
	            <tr data-denomination="100">
	              <td class="px-5">GH&cent;100</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Volume" readonly></td>
	            </tr>
	             <tr data-denomination="50">
	              <td class="px-5">GH&cent;50</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="20">
	              <td class="px-5">GH&cent;20</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="10">
	              <td class="px-5">GH&cent;10</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="5">
	              <td class="px-5">GH&cent;5</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="2">
	              <td class="px-5">GH&cent;2</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr data-denomination="1">
	              <td class="px-5">GH&cent;1</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	            <tr>
	              <td colspan="3">COINS</td>
	            </tr>
	            <tr data-denomination="2">
	              <td class="px-5">GH&cent;2</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="1">
	              <td class="px-5">GH&cent;1</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.5">
	              <td class="px-5">50p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.2">
	              <td class="px-5">20p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>

	            <tr data-denomination="0.1">
	              <td class="px-5">10p</td>
	              <td><input type="number" class="form-control p-1 count-input" placeholder="Enter count"></td>
	              <td><input type="text" class="form-control p-1 volume-input" placeholder="Enter volume" readonly></td>
	            </tr>
	          </tbody>
	          <tfoot>
	            <tr>
	              <th class="px-5 bg-secondary text-warning">TOTAL</th>
	              <th class="bg-secondary text-warning"><input type="text" class="form-control p-1" id="total-count" style="border:none; " placeholder="Total count" readonly></th>
	              <th class="bg-secondary text-warning"><input type="text" class="form-control p-1" id="total-volume" style="border:none; " placeholder="Total volume" readonly></th>
	            </tr>
	            <tr>
	              <th colspan="3" class="text-center">
	                <p class="text-danger mt-2" id="variance-display" style="display: none;"></p>
	              </th>
	            </tr>
	          </tfoot>
	        </table>
	      </div>

	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-danger reset" >Reset</button>
	        <button type="button" class="btn btn-warning restore" >Restore</button>
	        <button type="button" class="btn btn-primary submit">Confirm</button>
	      </div>
	    </div>
	  </div>
	</div>

<?php else:?>
	<div class="alert alert-danger text-center">
		Access denied. You dont have permission for this action
	</div>
<?php endif?>

<script>

	const sourceOptions = {
		"Withdrawal (CIT)": [
			{ value: "", text: "---Select---" },
			{ value: "GhQR", text: "GhQR" },
			{ value: "Calbank", text: "Calbank" },
			{ value: "Ecobank", text: "Ecobank" },
		],
		"Withdrawal (AIT)": [
			{ value: "", text: "---Select---" },
			{ value: "Gtbank", text: "Gtbank" },
			{ value: "Fidelity", text: "Fidelity" },
		],
	};

	const transactionType = document.getElementById('transaction_type');
	const sourceSelect = document.getElementById('network');
	const amountInput = document.getElementById('amount');
	const amountWithdrawnInput = document.getElementById('amount_withdrawn');
	const amountPayableInput = document.getElementById('amount_payable');
	const balanceBeforeInput = document.getElementById('balance_before');
	const newBalanceLabel = document.querySelector('.balance .form-label');
	const saveButton = document.querySelector('.btn-danger');

	function updateSourceOptions() {
		const transactionTypeValue = transactionType.value;
		sourceSelect.innerHTML = "";

		if (sourceOptions[transactionTypeValue]) {
			sourceOptions[transactionTypeValue].forEach(option => {
				const opt = document.createElement('option');
				opt.value = option.value;
				opt.textContent = option.text;
				sourceSelect.appendChild(opt);
			});
		}
		showFields();
	}

	const sofOptions = {

		"Telco": [
			{ value: "", text: "---Select---" },
			{ value: "AT", text: "AT" },
			{ value: "MTN-SUBSCRIBER", text: "MTN-SUBSCRIBER" },
			{ value: "MTN-AGENT", text: "MTN-AGENT" },
			{ value: "MTN-MERCHANT", text: "MTN-MERCHANT" },
			{ value: "TELECEL-SUBSCRIBER", text: "TELECEL-SUBSCRIBER" },
			{ value: "G-MONEY", text: "G-MONEY" },
			{ value: "GHANAPAY", text: "GHANAPAY" },
			{ value: "ZEEPAY", text: "ZEEPAY" },
			{ value: "OTHER MERCHANTS", text: "OTHER MERCHANTS" },
		],

		"Bank": [
			{ value: "", text: "---Select---" },
			{ value: "ABSA", text: "ABSA" },
			{ value: " Access Bank", text: " Access Bank" },
			{ value: "ADB", text: "ADB" },
			{ value: "APEX BANK", text: "APEX BANK" },
			{ value: "Bank of Africa", text: "Bank of Africa" },
			{ value: "CBG", text: "CBG" },
			{ value: "Cal Bank", text: "Cal Bank" },
			{ value: "Ecobank", text: "Ecobank" },
			{ value: "Fidelity", text: "Fidelity" },
			{ value: "First Atlantic Bank", text: "First Atlantic Bank" },
			{ value: "First Bank Ghana", text: "First Bank Ghana" },
			{ value: "FBN", text: "FBN" },
			{ value: "FNB", text: "FNB" },
			{ value: "Gtbank", text: "Gtbank" },
			{ value: "GCB", text: "GCB" },
			{ value: "NIB", text: "NIB" },
			{ value: "Republic Bank", text: "Republic Bank" },
			{ value: "OmniBSIC Bank", text: "OmniBSIC Bank" },
			{ value: "Society General", text: "Society General" },
			{ value: " Stanbic Bank", text: " Stanbic Bank" },
			{ value: "Prudential Bank", text: "Prudential Bank" },
			{ value: "Standard Charted", text: "Standard Charted" },
			{ value: "Zenit Bank", text: "Zenit Bank" },
			{ value: "umb", text: "umb" },
			{ value: "Zenit Bank", text: "Zenit Bank" },
		],
	};

	const sof_optionSelect = document.getElementById('sof_option');
	const sofSelect = document.getElementById('sof');
	const sofDiv = document.querySelector('.sof');
	const categorySelect = document.getElementById('category');

	function updateSofOptions() {
		const sofSelectValue = sof_optionSelect.value;
		sofSelect.innerHTML = "";

		if (sofOptions[sofSelectValue]) {
			sofOptions[sofSelectValue].forEach(option => {
				const opt = document.createElement('option');
				opt.value = option.value;
				opt.textContent = option.text;
				sofSelect.appendChild(opt);
			});
		}
	}

	sof_optionSelect.addEventListener('change', function(){
		updateSofOptions();
		validateForm();
	});

	sourceSelect.addEventListener('change', function(){
		showFields();
		validateForm();
	});

	categorySelect.addEventListener('change', function(){
		showFields();
		validateForm();
	});

	function showFields() {
		const transactionTypeValue = transactionType.value;
		const sourceValue = sourceSelect.value;
		const category = document.querySelector('.category');
		const payment_medium = document.querySelector('.payment_medium');
		const amountWithdrawn = document.querySelector('.amount_withdrawn');
		const amount_payable = document.querySelector('.amount_payable');
		const sof_option = document.querySelector('.sof_option');
		const sof = document.querySelector('.sof');
		const phone = document.querySelector('.phone');
		const otherPartyNumber = document.querySelector('.otherPartyNumber');
		const phoneLabel = document.querySelector('.phoneLabel');
		const account_number = document.querySelector('.account_number');
		const new_balance_div = document.querySelector('.balance');
		const balance_before_div = document.querySelector('.balance_before');
		const amountMatchError = document.getElementById('amount-match-error');

		// Hide all fields initially
		category.classList.add('d-none');
		payment_medium.classList.add('d-none');
		amountWithdrawn.classList.add('d-none');
		sof_option.classList.add('d-none');
		sof.classList.add('d-none');
		amount_payable.classList.add('d-none');
		otherPartyNumber.classList.add('d-none');
		balance_before_div.classList.add('d-none');
		new_balance_div.classList.add('d-none');

		// Show fields based on selected transaction type
		if (transactionTypeValue === 'Withdrawal (CIT)') {
			// Fields for CIT
			balance_before_div.classList.remove('d-none');
			amountWithdrawn.classList.remove('d-none');
			new_balance_div.classList.remove('d-none');
			newBalanceLabel.textContent = "Balance after";
			amountMatchError.style.display = 'none';

			if (sourceValue === 'GhQR') {
				category.classList.remove('d-none');
				payment_medium.classList.remove('d-none');
				sof_option.classList.remove('d-none');
				sof.classList.remove('d-none');
				amount_payable.classList.remove('d-none');
				account_number.classList.add('d-none');
				if (categorySelect.value === 'Self') {
					phoneLabel.innerText = "Customer's Number";
					phone.classList.remove('d-none');
				} else if (categorySelect.value === '3rd Party') {
					phoneLabel.innerText = "Customer's Number";
					phone.classList.remove('d-none');
					otherPartyNumber.classList.remove('d-none');
				}
			}

		} else if (transactionTypeValue === 'Withdrawal (AIT)') {
			// Fields for AIT
			amountWithdrawn.classList.remove('d-none');
			balance_before_div.classList.add('d-none'); // Remove Balance before
			new_balance_div.classList.add('d-none'); // Hide the new balance field
			newBalanceLabel.textContent = "New Balance"; // Reset label for consistency
			amountMatchError.style.display = 'none';

		} else {
			// Other transaction types
			// You can add logic for other transaction types here if needed
			newBalanceLabel.textContent = "New Balance";
		}
		validateForm();
	}

	function validateForm() {
		const transactionTypeValue = transactionType.value;
		const amountWithdrawnValue = amountWithdrawnInput.value;
		const amountPaidOutValue = amountInput.value;
		const walletInId = document.getElementById('wallet_in_id').value;
		const walletOutId = document.getElementById('wallet_out_id').value;
		const transactionStatus = document.querySelector('.transaction_status').value;

		const isGhQR_CIT = transactionTypeValue === 'Withdrawal (CIT)' && sourceSelect.value === 'GhQR';

		// Check for basic required fields
		if (!transactionTypeValue || !amountWithdrawnValue || !amountPaidOutValue || !walletInId || !walletOutId || !transactionStatus) {
			saveButton.classList.add('disabled');
			return false;
		}

		// Specific validation for 'Withdrawal (CIT)'
		if (transactionTypeValue === 'Withdrawal (CIT)') {
			const balanceBeforeValue = balanceBeforeInput.value;
			const newBalance = parseFloat(balanceBeforeValue) - parseFloat(amountPaidOutValue);
			if (!balanceBeforeValue || newBalance < 0) {
				saveButton.classList.add('disabled');
				return false;
			}
		}

		// Ensure amounts match with a small tolerance
		const EPSILON = 0.001;
		let amountToMatch = parseFloat(amountWithdrawnValue);

		if (isGhQR_CIT) {
			amountToMatch = parseFloat(amountPayableInput.value) || 0;
		}

		if (Math.abs(amountToMatch - parseFloat(amountPaidOutValue)) > EPSILON) {
			saveButton.classList.add('disabled');
			return false;
		}


		// If all checks pass, enable the button
		saveButton.classList.remove('disabled');
		return true;
	}

	function calculateBalance() {
		const transactionTypeValue = transactionType.value;
		const balanceBefore = parseFloat(balanceBeforeInput.value) || 0;
		const amount = parseFloat(amountInput.value) || 0;
		const balanceField = document.getElementById('balance');
		const balanceError = document.getElementById('balance-error');

		let newBalance = balanceBefore;

		if (transactionTypeValue === 'Withdrawal (CIT)') {
			newBalance = balanceBefore - amount;
			balanceField.value = newBalance.toFixed(2);
			if (newBalance < 0) {
				balanceError.textContent = 'Insufficient balance';
				saveButton.classList.add('disabled');
			} else {
				balanceError.textContent = '';
				validateForm();
			}
		}
	}

	amount_withdrawn.addEventListener('input', calculateAmountPayable);
	amount_withdrawn.addEventListener('input', validateForm);

	function calculateAmountPayable() {
		const amountWithdrawn = parseFloat(amount_withdrawn.value) || 0;
		const charge_rate = <?=$settings->agencybanking_charges ?? 0?>;
		const charge = amountWithdrawn * charge_rate;
		const maxCharge = 20;
		if (amountWithdrawn < 2000) {
			amount_payable.value = (amountWithdrawn - charge).toFixed(2);
		}else{
			amount_payable.value = (amountWithdrawn - maxCharge).toFixed(2);
		}
		validateForm();
	}

	document.addEventListener("DOMContentLoaded", function () {
		const countInputs = document.querySelectorAll(".count-input");
		const totalCountField = document.getElementById("total-count");
		const totalVolumeField = document.getElementById("total-volume");
		const denosField = document.querySelector("#denos");
		const submitBtn = document.querySelector('.submit');
		const restoreBtn = document.querySelector('.restore');
		const resetBtn = document.querySelector('.reset');
		const staticBackdropModal = new bootstrap.Modal(document.getElementById('staticBackdrop'));
		const amountMatchError = document.getElementById('amount-match-error');
		const amountInput = document.getElementById("amount");
		const varianceDisplay = document.getElementById('variance-display');

		const savedDenos = localStorage.getItem("denosData");

		validateForm();

		function restoreDenominations() {
			if (savedDenos) {
				const currency = JSON.parse(savedDenos);

				currency.forEach((item, index) => {
					const input = countInputs[index];
					if (input) {
						const row = input.closest("tr");
						const volumeField = row.querySelector(".volume-input");

						input.value = item.count;
						volumeField.value = (item.denomination * item.count).toFixed(2);
					}
				});
				updateVolumesAndTotals();
			}
		}

		function resetDenominations() {
			if (savedDenos) {
				const currency = JSON.parse(savedDenos);

				currency.forEach((item, index) => {
					const input = countInputs[index];
					if (input) {
						const volumeField = input.closest("tr").querySelector(".volume-input");
						input.value = '';
						volumeField.value = '';
					}
				});
				updateVolumesAndTotals();
			}
		}

		countInputs.forEach(input => {
			input.addEventListener("input", updateVolumesAndTotals);
		});

		function updateVolumesAndTotals() {
			let totalCount = 0;
			let totalVolume = 0;
			const currency = [];

			countInputs.forEach(input => {
				const row = input.closest("tr");
				const denomination = parseFloat(row.getAttribute("data-denomination"));
				const count = parseFloat(input.value) || 0;
				const volumeField = row.querySelector(".volume-input");
				const volume = denomination * count;

				volumeField.value = volume.toFixed(2);
				totalCount += count;
				totalVolume += volume;

				if (count > 0) {
					const denos = {
						currency: `GHS`,
						denomination: denomination,
						count: count,
						volume: volume,
					};
					currency.push(denos);
				}
			});

			totalCountField.value = totalCount;
			totalVolumeField.value = totalVolume.toFixed(2);

			const serializedCurrency = JSON.stringify(currency);
			localStorage.setItem("denosData", serializedCurrency);
			denosField.value = serializedCurrency;
		}

		submitBtn.addEventListener('click', function() {
			const amountWithdrawnValue = parseFloat(amountWithdrawnInput.value) || 0;
			const totalVolumeValue = parseFloat(totalVolumeField.value) || 0;
			const EPSILON = 0.001;
			const isGhQR_CIT = transactionType.value === 'Withdrawal (CIT)' && sourceSelect.value === 'GhQR';

			let amountToMatch = amountWithdrawnValue;
			if(isGhQR_CIT){
				amountToMatch = parseFloat(amountPayableInput.value) || 0;
			}
			const variance = Math.abs(amountToMatch - totalVolumeValue);

			if (amountWithdrawnValue === 0) {
				varianceDisplay.textContent = 'Please enter an amount to withdraw first.';
				varianceDisplay.style.display = 'block';
				saveButton.classList.add('disabled');
				return;
			}

			if (Math.abs(amountToMatch - totalVolumeValue) > EPSILON) {
				varianceDisplay.textContent = `Variance: GH₵${variance.toFixed(2)}. The amount paid out does not match the required amount.`;
				varianceDisplay.style.display = 'block';
				saveButton.classList.add('disabled');
				return;
			} else {
				varianceDisplay.style.display = 'none';
			}

			amountInput.value = totalVolumeValue.toFixed(2);
			updateVolumesAndTotals();
			calculateBalance();
			staticBackdropModal.hide();
			validateForm();
		});


		restoreBtn.addEventListener('click', function() {
			restoreDenominations();
		});

		resetBtn.addEventListener('click', function() {
			resetDenominations();
		});

		updateSourceOptions();
		calculateBalance();
	});

	transactionType.addEventListener("change", updateSourceOptions);
	transactionType.addEventListener("change", calculateBalance);
	transactionType.addEventListener("change", validateForm);

	amountInput.addEventListener('input', calculateBalance);
	amountInput.addEventListener('input', validateForm);

	balanceBeforeInput.addEventListener('input', calculateBalance);
	balanceBeforeInput.addEventListener('input', validateForm);

	amountWithdrawnInput.addEventListener('input', () => {
		const amountPaidOut = parseFloat(amountInput.value) || 0;
		const amountWithdrawn = parseFloat(amountWithdrawnInput.value) || 0;
		const amountMatchError = document.getElementById('amount-match-error');
		const EPSILON = 0.001;
		const isGhQR_CIT = transactionType.value === 'Withdrawal (CIT)' && sourceSelect.value === 'GhQR';

		let amountToMatch = amountWithdrawn;
		if(isGhQR_CIT) {
			amountToMatch = parseFloat(amountPayableInput.value) || 0;
		}

		if (amountPaidOut === 0) {
			amountMatchError.style.display = 'none';
			saveButton.classList.add('disabled');
			return;
		}

		if (Math.abs(amountToMatch - amountPaidOut) > EPSILON) {
			amountMatchError.style.display = 'block';
			saveButton.classList.add('disabled');
		} else {
			amountMatchError.style.display = 'none';
			validateForm();
		}
	});


	document.getElementById('wallet_in_id').addEventListener('change', validateForm);
	document.getElementById('wallet_out_id').addEventListener('change', validateForm);
	document.querySelector('.transaction_status').addEventListener('change', validateForm);
	document.getElementById('phone').addEventListener('input', validateForm);
	document.getElementById('other_phone').addEventListener('input', validateForm);
	document.getElementById('account_number').addEventListener('input', validateForm);
	document.getElementById('amount_payable').addEventListener('input', validateForm);
	document.getElementById('sof').addEventListener('change', validateForm);
	document.getElementById('payment_medium').addEventListener('change', validateForm);

</script>
<?php

date_default_timezone_set('Africa/Accra');

if (empty($row))
{
	message_fail("Record not found");
	return;
}

$cashdrawer = new \MyWallets\Cashdrawer;
$drawerdenos = new \MyWallets\DrawerDenos;

// Load CFA cashdrawer sync helper (if available) to mirror CFA denominations
$cfaHelperPath = realpath(__DIR__ . '/../../cfa/helpers/cashdrawer-sync.php');
if ($cfaHelperPath && file_exists($cfaHelperPath)) {
	require_once $cfaHelperPath;
}

$postdata = $req->post();
$currencyDetails = $postdata['denos'] ?? '[]';

// Collect dynamic e-cash channels coming from the form.
$ecashChannels = [];
$ecashProofUploads = [];
foreach ($postdata as $field => $value) {
	if (strpos($field, 'ecash_') !== 0) {
		continue;
	}

	$amount = (float) $value;
	if ($amount < 0) {
		continue;
	}
	if (!is_finite($amount)) {
		$amount = 0;
	}

	$rawKey = strtoupper(substr($field, 6));
	$sanitizedKey = preg_replace('/[^A-Z0-9]+/', '_', $rawKey);
	$sanitizedKey = trim($sanitizedKey, '_');
	if (empty($sanitizedKey)) {
		$sanitizedKey = 'CUSTOM';
	}
	if (in_array($sanitizedKey, ['EZWICH', 'E_ZWICH'], true)) {
		continue;
	}

	$channelKey = 'ECASH_' . $sanitizedKey;
	$ecashChannels[$channelKey] = $amount;
	$ecashProofUploads[$channelKey] = 'ecash_proof_' . strtolower(substr($field, 6));
}

$currencyArray = json_decode($currencyDetails, true);

$postdata['id'] = $row->id;
$csrf = csrf_verify($postdata);
if (!$csrf) {
	$cashdrawer->errors['user_id'] = "Form expired!";
	set_value('errors', array_merge($cashdrawer->errors, $req->upload_errors));
	return;
}

if (!user_can('edit_wallet'))
{
	message_fail('Access denied');
	return;
}

// Upload proofs (only required when amount > 0 and no existing proof exists)
$existingProofs = [];
try {
	$db = new \Core\Database;
	if ($db->table_exists(['drawer_balances'])) {
		$rows = $db->query(
			"SELECT channel_key, proof_image FROM drawer_balances WHERE drawer_id = :drawer_id AND channel_type = 'ecash'",
			['drawer_id' => $row->id]
		) ?: [];
		foreach ($rows as $r) {
			$key = (string)($r->channel_key ?? '');
			if ($key === '') continue;
			$existingProofs[$key] = (string)($r->proof_image ?? '');
		}
	}
} catch (\Throwable $e) {
	$existingProofs = [];
}

if (!empty($ecashChannels)) {
	$req->upload_folder = 'uploads/cashdrawers';
	try {
		$dbSchema = new \Core\Database;
		if ($dbSchema->table_exists(['drawer_balances'])) {
			$schema = $dbSchema->query("SHOW COLUMNS FROM drawer_balances") ?: [];
			$existing = [];
			foreach ($schema as $column) {
				$existing[strtolower($column->Field ?? '')] = true;
			}
			if (empty($existing['proof_image'])) {
				$dbSchema->query("ALTER TABLE drawer_balances ADD COLUMN proof_image VARCHAR(255) NULL AFTER trans_status");
			}
		}
	} catch (\Throwable $e) {
		// ignore
	}

	foreach ($ecashProofUploads as $channelKey => $fileKey) {
		$openingBalance = isset($ecashChannels[$channelKey]) ? (float)$ecashChannels[$channelKey] : 0.0;
		if ($openingBalance <= 0) {
			$ecashProofUploads[$channelKey] = null;
			continue;
		}

		$hasExisting = !empty($existingProofs[$channelKey]);
		$uploadedProof = $req->upload_files($fileKey);
		$hasNewUpload = !empty($uploadedProof) && empty($req->upload_errors[$fileKey]);
		if (!$hasNewUpload && !$hasExisting) {
			$displayChannel = preg_replace('/^ECASH_/', '', (string)$channelKey);
			$displayChannel = ucwords(strtolower(str_replace('_', ' ', $displayChannel)));
			$cashdrawer->errors[$fileKey] = $req->upload_errors[$fileKey] ?? ("Upload photo proof for {$displayChannel} because opening balance is greater than 0.");
		} else {
			$ecashProofUploads[$channelKey] = $hasNewUpload ? $uploadedProof : ($existingProofs[$channelKey] ?? null);
		}
	}
}

if (!empty($cashdrawer->errors)) {
	set_value('errors', array_merge($cashdrawer->errors, $req->upload_errors));
	return;
}

// Persist CFA rates to settings if operations manager posted them
try {
	$session = get_session();
	$rolesRaw = $session->roles ?? [];
	if (!is_array($rolesRaw)) {
		$rolesRaw = [$rolesRaw];
	}
	$rolesLower = array_map('strtolower', $rolesRaw);
	$isOpsManager = in_array('operations manager', $rolesLower, true);
	if ($isOpsManager) {
		$buyingRatePost  = isset($postdata['buying_rate'])  ? (float)$postdata['buying_rate']  : null;
		$sellingRatePost = isset($postdata['selling_rate']) ? (float)$postdata['selling_rate'] : null;
		if ($buyingRatePost !== null || $sellingRatePost !== null) {
			$settingsModel = new \Settings\Setting;
			$settingsRow = $settingsModel->first(['id' => 1]);
			$updateData = [];
			if ($buyingRatePost !== null && $buyingRatePost > 0) {
				$updateData['buying_rate'] = $buyingRatePost;
			}
			if ($sellingRatePost !== null && $sellingRatePost > 0) {
				$updateData['selling_rate'] = $sellingRatePost;
			}
			if (!empty($updateData)) {
				if ($settingsRow) {
					$settingsModel->update($settingsRow->id, $updateData);
				} else {
					$updateData['id'] = 1;
					$settingsModel->insert($updateData);
				}
			}
		}
	}
} catch (\Throwable $e) {
	// ignore
}

// Update cashdrawer header
$session = get_session();
$user_id = (int)($session->id ?? 0);
$drawerOwnerUserId = (int)($row->user_id ?? 0);
if ($drawerOwnerUserId <= 0) {
	$drawerOwnerUserId = (int)($postdata['user_id'] ?? 0);
}
if ($drawerOwnerUserId <= 0) {
	$cashdrawer->errors['user_id'] = 'Cashdrawer owner could not be resolved.';
	set_value('errors', array_merge($cashdrawer->errors, $req->upload_errors));
	return;
}
$update = [
	'currency' => (string)($postdata['currency'] ?? $row->currency ?? 'GHS'),
	'amount' => (float)($postdata['amount'] ?? $row->amount ?? 0),
	'updated_by' => $user_id,
	'date_updated' => date('Y-m-d H:i:s'),
];

$oldGhsDenoCounts = [];
$oldCfaDenoCounts = [];
$oldGhsDenoTotal = 0.0;
$oldCfaDenoTotal = 0.0;
$oldEcashTotal = 0.0;
$oldEcashCount = 0;
$loadExistingDenoCounts = static function(\Core\Database $database, string $table, int $drawerId, int $ownerId, string $currency = ''): array {
	$out = [];
	if (!$database->table_exists([$table])) {
		return $out;
	}
	$where = "drawer_id = :drawer_id";
	$params = ['drawer_id' => $drawerId];
	if ($ownerId > 0) {
		$where .= " AND user_id = :user_id";
		$params['user_id'] = $ownerId;
	}
	if ($currency !== '') {
		try {
			$cols = $database->query("SHOW COLUMNS FROM {$table}") ?: [];
			$hasCurrency = false;
			foreach ($cols as $col) {
				if (strtolower((string)($col->Field ?? '')) === 'currency') {
					$hasCurrency = true;
					break;
				}
			}
			if ($hasCurrency) {
				$where .= " AND currency = :currency";
				$params['currency'] = $currency;
			}
		} catch (\Throwable $e) {
		}
	}
	$rows = $database->query(
		"SELECT denomination, SUM(`count`) AS total_count FROM {$table} WHERE {$where} GROUP BY denomination",
		$params
	) ?: [];
	foreach ($rows as $denoRow) {
		$key = number_format((float)($denoRow->denomination ?? 0), 2, '.', '');
		if ((float)$key <= 0) {
			continue;
		}
		$out[$key] = (int)round((float)($denoRow->total_count ?? 0));
	}
	return $out;
};
$sumDenoMap = static function(array $map): float {
	$total = 0.0;
	foreach ($map as $denomination => $count) {
		$total += (float)$denomination * (int)$count;
	}
	return $total;
};
$newGhsDenoCounts = [];
$newCfaDenoCounts = [];
if (is_array($currencyArray)) {
	foreach ($currencyArray as $currency) {
		$currencyCode = strtoupper((string)($currency['currency'] ?? 'GHS'));
		$denomination = (float)($currency['denomination'] ?? 0);
		$count = (int)($currency['count'] ?? 0);
		if ($denomination <= 0 || $count <= 0) {
			continue;
		}
		$key = number_format($denomination, 2, '.', '');
		if ($currencyCode === 'CFA') {
			$newCfaDenoCounts[$key] = ($newCfaDenoCounts[$key] ?? 0) + $count;
		} elseif ($currencyCode === 'GHS') {
			$newGhsDenoCounts[$key] = ($newGhsDenoCounts[$key] ?? 0) + $count;
		}
	}
}
try {
	$auditDb = new \Core\Database;
	$oldGhsDenoCounts = $loadExistingDenoCounts($auditDb, 'drawer_denos', (int)$row->id, $drawerOwnerUserId);
	$oldCfaDenoCounts = $loadExistingDenoCounts($auditDb, 'drawer_fx_denos', (int)$row->id, $drawerOwnerUserId, 'CFA');
	$oldGhsDenoTotal = $sumDenoMap($oldGhsDenoCounts);
	$oldCfaDenoTotal = $sumDenoMap($oldCfaDenoCounts);
	if ($auditDb->table_exists(['drawer_balances'])) {
		$oldEcashRow = ($auditDb->query(
			"SELECT COUNT(*) AS total_count, SUM(opening_balance) AS total_balance FROM drawer_balances WHERE drawer_id = :drawer_id AND user_id = :user_id AND channel_type = 'ecash'",
			['drawer_id' => (int)$row->id, 'user_id' => $drawerOwnerUserId]
		) ?: [])[0] ?? null;
		if ($oldEcashRow) {
			$oldEcashCount = (int)($oldEcashRow->total_count ?? 0);
			$oldEcashTotal = (float)($oldEcashRow->total_balance ?? 0);
		}
	}
} catch (\Throwable $e) {
	$oldGhsDenoCounts = [];
	$oldCfaDenoCounts = [];
}
$cashdrawer->update($row->id, $update);

// Detect optional history columns in drawer_denos so opening snapshot can be grouped
$drawerDenosHasTransId = false;
$drawerDenosHasTransStatus = false;
$drawerFxDenosHasTransId = false;
$drawerFxDenosHasTransStatus = false;
$drawerFxDenosHasCurrency = false;
try {
	$dbSchema = new \Core\Database;
	if ($dbSchema->table_exists(['drawer_denos'])) {
		$ddSchema = $dbSchema->query("SHOW COLUMNS FROM drawer_denos") ?: [];
		$ddCols = [];
		foreach ($ddSchema as $col) {
			$ddCols[strtolower((string)($col->Field ?? ''))] = true;
		}
		$drawerDenosHasTransId = !empty($ddCols['trans_id']);
		$drawerDenosHasTransStatus = !empty($ddCols['trans_status']);
	}
	if ($dbSchema->table_exists(['drawer_fx_denos'])) {
		$fxSchema = $dbSchema->query("SHOW COLUMNS FROM drawer_fx_denos") ?: [];
		$fxCols = [];
		foreach ($fxSchema as $col) {
			$fxCols[strtolower((string)($col->Field ?? ''))] = true;
		}
		$drawerFxDenosHasTransId = !empty($fxCols['trans_id']);
		$drawerFxDenosHasTransStatus = !empty($fxCols['trans_status']);
		$drawerFxDenosHasCurrency = !empty($fxCols['currency']);
	}
} catch (\Throwable $e) {
	$drawerDenosHasTransId = false;
	$drawerDenosHasTransStatus = false;
	$drawerFxDenosHasTransId = false;
	$drawerFxDenosHasTransStatus = false;
	$drawerFxDenosHasCurrency = false;
}

// Rebuild denominations snapshot (GHS + CFA opening rows)
try {
	$db = new \Core\Database;
	if ($db->table_exists(['drawer_denos'])) {
		$db->query("DELETE FROM drawer_denos WHERE drawer_id = :drawer_id", ['drawer_id' => $row->id]);
	}
	if ($db->table_exists(['drawer_fx_denos'])) {
		$db->query("DELETE FROM drawer_fx_denos WHERE drawer_id = :drawer_id", ['drawer_id' => $row->id]);
	}
} catch (\Throwable $e) {
	// ignore
}

$openingCfaTotal = 0.0;
if (is_array($currencyArray) && !empty($currencyArray)) {
	foreach ($currencyArray as $currency) {
		$currencyCode = strtoupper($currency['currency'] ?? 'GHS');
		$denomination = (float)($currency['denomination'] ?? 0);
		$count = (int)($currency['count'] ?? 0);
		$volume = (float)($currency['volume'] ?? 0);
		if ($count <= 0 || $volume <= 0 || $denomination <= 0) {
			continue;
		}

		if ($currencyCode === 'CFA') {
			try {
				$db = new \Core\Database;
				$params = [
					'drawer_id' => (int)$row->id,
					'user_id' => $drawerOwnerUserId,
					'denomination' => $denomination,
					'count' => $count,
					'volume' => $volume,
					'date_created' => date('Y-m-d H:i:s'),
					'created_by' => $user_id,
				];
				$columns = ['drawer_id', 'user_id'];
				$values = [':drawer_id', ':user_id'];
				if ($drawerFxDenosHasCurrency) {
					$columns[] = 'currency';
					$values[] = ':currency';
					$params['currency'] = 'CFA';
				}
				$columns = array_merge($columns, ['denomination', '`count`', 'volume', 'date_created', 'created_by']);
				$values = array_merge($values, [':denomination', ':count', ':volume', ':date_created', ':created_by']);
				if ($drawerFxDenosHasTransId) {
					$columns[] = 'trans_id';
					$values[] = ':trans_id';
					$params['trans_id'] = (int)$row->id;
				}
				if ($drawerFxDenosHasTransStatus) {
					$columns[] = 'trans_status';
					$values[] = ':trans_status';
					$params['trans_status'] = 'Opening CFA Snapshot';
				}
				$db->query(
					"INSERT INTO drawer_fx_denos (" . implode(',', $columns) . ") VALUES (" . implode(',', $values) . ")",
					$params
				);
				$openingCfaTotal += $volume;
			} catch (\Throwable $e) {
				// ignore
			}
			continue;
		}

		if ($currencyCode !== 'GHS') {
			continue;
		}
		$denosPost = [
			'user_id' => $drawerOwnerUserId,
			'drawer_id' => (int)$row->id,
			'denomination' => $denomination,
			'count' => $count,
			'volume' => $volume,
			'created_by' => $user_id,
			'date_created' => date('Y-m-d H:i:s'),
		];
		if ($drawerDenosHasTransId) {
			$denosPost['trans_id'] = (int)$row->id;
		}
		if ($drawerDenosHasTransStatus) {
			$denosPost['trans_status'] = 'Opening Snapshot';
		}
		$drawerdenos->insert($denosPost);
	}
}

// Rebuild drawer_balances opening snapshot for cash + ecash
try {
	$db = new \Core\Database;
	if ($db->table_exists(['drawer_balances'])) {
		$db->query("DELETE FROM drawer_balances WHERE drawer_id = :drawer_id AND channel_type IN ('cash','ecash')", ['drawer_id' => $row->id]);
		$now = date('Y-m-d H:i:s');
		$openingCash = (float)($update['amount'] ?? 0);
		if ($openingCash > 0) {
			$db->query(
				"INSERT INTO drawer_balances (drawer_id, user_id, channel_type, channel_key, opening_balance, credit, debit, closing_balance, date_created) VALUES (:drawer_id, :user_id, 'cash', :channel_key, :opening_balance, 0, 0, :closing_balance, :date_created)",
				[
					'drawer_id' => $row->id,
					'user_id' => $drawerOwnerUserId,
					'channel_key' => 'CASH_DRAWER',
					'opening_balance' => $openingCash,
					'closing_balance' => $openingCash,
					'date_created' => $now,
				]
			);
		}
		if ($openingCfaTotal > 0) {
			$db->query(
				"INSERT INTO drawer_balances (drawer_id, user_id, channel_type, channel_key, opening_balance, credit, debit, closing_balance, date_created) VALUES (:drawer_id, :user_id, 'cash', :channel_key, :opening_balance, 0, 0, :closing_balance, :date_created)",
				[
					'drawer_id' => $row->id,
					'user_id' => $drawerOwnerUserId,
					'channel_key' => 'CASH_CFA',
					'opening_balance' => $openingCfaTotal,
					'closing_balance' => $openingCfaTotal,
					'date_created' => $now,
				]
			);
		}
		if (!empty($ecashChannels)) {
			foreach ($ecashChannels as $channelKey => $openingBalance) {
				$openingBalance = (float)$openingBalance;
				if ($openingBalance < 0) continue;
				$db->query(
					"INSERT INTO drawer_balances (drawer_id, user_id, channel_type, channel_key, opening_balance, credit, debit, closing_balance, proof_image, date_created) VALUES (:drawer_id, :user_id, 'ecash', :channel_key, :opening_balance, 0, 0, :closing_balance, :proof_image, :date_created)",
					[
						'drawer_id' => $row->id,
						'user_id' => $drawerOwnerUserId,
						'channel_key' => $channelKey,
						'opening_balance' => $openingBalance,
						'closing_balance' => $openingBalance,
						'proof_image' => $ecashProofUploads[$channelKey] ?? null,
						'date_created' => $now,
					]
				);
			}
		}
	}
} catch (\Throwable $e) {
	// ignore
}

try {
	$username = 'System';
	if (!empty($session->id)) {
		$username = trim((string)($session->first_name ?? '') . ' ' . (string)($session->last_name ?? ''));
		if ($username === '') {
			$username = 'User #' . (int)$session->id;
		}
	}
	$describeDenoChanges = static function(array $oldMap, array $newMap, string $currency): string {
		$keys = array_unique(array_merge(array_keys($oldMap), array_keys($newMap)));
		usort($keys, static function($a, $b) {
			return (float)$b <=> (float)$a;
		});
		$parts = [];
		foreach ($keys as $key) {
			$oldCount = (int)($oldMap[$key] ?? 0);
			$newCount = (int)($newMap[$key] ?? 0);
			if ($oldCount === $newCount) {
				continue;
			}
			$label = $currency . ' ' . (((float)$key >= 1) ? number_format((float)$key, 0) : number_format((float)$key, 2));
			$oldVolume = (float)$key * $oldCount;
			$newVolume = (float)$key * $newCount;
			$parts[] = $label . ': '
				. number_format($oldCount) . ' (' . $currency . ' ' . number_format($oldVolume, 2) . ')'
				. ' -> '
				. number_format($newCount) . ' (' . $currency . ' ' . number_format($newVolume, 2) . ')';
			if (count($parts) >= 8) {
				$parts[] = 'more changes';
				break;
			}
		}
		return empty($parts) ? ($currency . ' denominations unchanged') : implode('; ', $parts);
	};
	$newGhsDenoTotal = $sumDenoMap($newGhsDenoCounts);
	$newCfaDenoTotal = $sumDenoMap($newCfaDenoCounts);
	$newEcashTotal = 0.0;
	$newEcashCount = 0;
	foreach ($ecashChannels as $openingBalance) {
		$newEcashCount++;
		$newEcashTotal += (float)$openingBalance;
	}
	$descriptionParts = [];
	$descriptionParts[] = $username . ' edited cashdrawer #' . (int)$row->id;
	$descriptionParts[] = 'Opening GHS: ' . number_format((float)($row->amount ?? 0), 2) . ' -> ' . number_format((float)($update['amount'] ?? 0), 2);
	$descriptionParts[] = 'GHS total: ' . number_format($oldGhsDenoTotal, 2) . ' -> ' . number_format($newGhsDenoTotal, 2);
	$descriptionParts[] = 'CFA total: ' . number_format($oldCfaDenoTotal, 2) . ' -> ' . number_format($newCfaDenoTotal, 2);
	$descriptionParts[] = 'E-cash total: ' . number_format($oldEcashTotal, 2) . ' (' . number_format($oldEcashCount) . ' channels) -> ' . number_format($newEcashTotal, 2) . ' (' . number_format($newEcashCount) . ' channels)';
	$descriptionParts[] = $describeDenoChanges($oldGhsDenoCounts, $newGhsDenoCounts, 'GHS');
	$descriptionParts[] = $describeDenoChanges($oldCfaDenoCounts, $newCfaDenoCounts, 'CFA');
	$marker = '[cashdrawer_id:' . (int)$row->id . ']';
	$description = implode('. ', array_filter($descriptionParts, static function($part) {
		return trim((string)$part) !== '';
	})) . '. ' . $marker;
	if (strlen($description) > 1000) {
		$maxBodyLength = max(0, 996 - strlen($marker));
		$body = implode('. ', array_filter($descriptionParts, static function($part) {
			return trim((string)$part) !== '';
		})) . '.';
		$body = substr($body, 0, $maxBodyLength);
		$body = rtrim($body, " .");
		$description = $body . '... ' . $marker;
	}
	$log = new \MyWallets\Log;
	$log->insert([
		'table_name' => 'cashdrawers',
		'action' => 'edited',
		'user_id' => $user_id,
		'user_name' => $username,
		'description' => $description,
		'date_created' => date('Y-m-d H:i:s'),
	]);
} catch (\Throwable $e) {
	// Logging should never block a cashdrawer correction.
}

message_success("Cashdrawer updated successfully!");
redirect($admin_route.'/'.$plugin_route);
